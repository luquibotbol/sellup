export default {
  background: "#1c1c1c",
  card: "#000000",
  accent: "#8eff60",
  text: "#ffffff",
  textSecondary: "#a0a0a0",
  border: "#333333",
  error: "#ff6060",
  success: "#60ff8e",
  overlay: "rgba(0, 0, 0, 0.7)",
};